# 1q84-emacs-config
用git管理配置文件的又一次尝试。
