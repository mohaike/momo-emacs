Please see README.md for documentation, or read it online at
https://github.com/Wilfred/ag.el/#agel
