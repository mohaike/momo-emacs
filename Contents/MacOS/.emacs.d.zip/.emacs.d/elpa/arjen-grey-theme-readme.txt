Theme based on space gray for xcode
