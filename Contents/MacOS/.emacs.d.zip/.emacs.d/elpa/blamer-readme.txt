Package for displaying git information about the current line or
about several selected lines. Works with git only.
