Major mode for editing blockdiag files.
