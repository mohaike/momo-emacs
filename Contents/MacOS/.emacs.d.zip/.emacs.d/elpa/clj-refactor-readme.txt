See README.md at https://github.com/clojure-emacs/clj-refactor.el
