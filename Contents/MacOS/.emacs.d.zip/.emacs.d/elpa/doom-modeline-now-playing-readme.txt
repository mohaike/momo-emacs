
 Depends on playerctl currently, not sure if I'm going
 to add support for anything else but feel free to contribute
 another provider :D

 The below line need to be manually ran somewhere at your behest

 (doom-modeline-now-playing-timer)

 If you wish for the staus to update
