helm-ag provides interfaces of the silver searcher(Other search programs can be used
such as the platinum searcher, ack). And helm-ag provides wgrep like features which
users can edit from searched result.
