omnisharp-emacs is a port of the awesome OmniSharp server to the
Emacs text editor. It provides IDE-like features for editing files
in C# solutions in Emacs, provided by an OmniSharp server instance
that works in the background.

See the project home page for more information.
