Simple parser for Mac OS X plist files. The main entry point is
`osx-plist-parse-file' (which see). As a useful example, code is
included to update Emacs' environment by parsing your
~/.MacOSX/environment.plist file (see `osx-plist-update-environment').
