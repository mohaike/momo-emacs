wgrep-ag allows you to edit a ag buffer and apply those changes to
the file buffer.
