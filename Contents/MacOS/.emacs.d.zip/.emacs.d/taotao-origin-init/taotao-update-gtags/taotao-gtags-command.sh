# 需要生成或者更新gtags三个文件 GTAGS GRTAGS GPATH 的工程目录，需要的更换
cd  /Users/1q84/Documents/Project/SM/StickMan/;
gtags;
