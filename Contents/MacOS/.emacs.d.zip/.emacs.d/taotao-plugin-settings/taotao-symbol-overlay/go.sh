CURRENT_PATH="$(cd $(dirname ${BASH_SOURCE:-$0});pwd)"

origin_file="${CURRENT_PATH}/momo.color"
color_file="${CURRENT_PATH}/kiki.color"
tmp_file="${CURRENT_PATH}/kiki.color.tmp"

:> "${color_file}"

go()
{
    color_str="${1}"
    color_index="${2}"
cat << MOMO >> "${color_file}"
(defface symbol-overlay-face-${color_index}
  '((t (:background "${color_str}" :foreground "black")))
  "Symbol Overlay default candidate ${color_index}"
  :group 'symbol-overlay)

MOMO
}

go "dodger blue" "1"
go "hot pink" "2"
go "yellow" "3"
go "orchid" "4"
go "red" "5"
go "salmon" "6"
go "spring green" "7"
go "turquoise" "8"
go "papaya whip" "9"
go "blanched almond" "10"
go "peach puff" "11"
go "seashell" "12"
go "misty rose" "13"
go "cornflower blue" "14"
go "deep sky blue" "15"
go "cyan" "16"
go "magenta" "17"
go "deep pink" "18"
go "SlateBlue1" "19"
go "IndianRed1" "20"
go "maroon1" "21"
go "DarkOrchid2" "22"
go "thistle1" "23"
go "LightPink1" "24"
go "OrangeRed1" "25"
go "tan1" "26"
go "chocolate1" "27"
go "firebrick1" "28"
go "salmon1" "29"
go "gold1" "30"

go1()
{
    local s0001="$(cat "${color_file}")"
    local s0002="$(cat "${color_file}" | grep -i "symbol-overlay-face" | sed 's/(defface //g')"
cat << MOMO > "${color_file}"
${s0001}

;;; Options

(defcustom symbol-overlay-faces '(${s0002})
MOMO
}
go1


m_diff()
{
    ksdiff "${origin_file}" "${color_file}"
}
m_diff
